       integer nadd, lay
       parameter (nadd=7,lay=326) ! lay = (nz-2)*2 + nadd - 1
