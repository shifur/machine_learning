       integer nadd, lay
       parameter (nadd=7,lay=126)
