        integer nx, ny, nz
        parameter (nx=1,ny=1,nz=162)